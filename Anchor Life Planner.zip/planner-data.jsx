// Shared state, design tokens, and mock data for the planner.

// ─────────────────────────────────────────────────────────────
// Tweakable defaults (editable via Tweaks panel)
// ─────────────────────────────────────────────────────────────
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "ochre",
  "typeface": "newsreader",
  "mode": "light",
  "density": "spacious",
  "widgets": {
    "tasks": true,
    "schedule": true,
    "habits": true,
    "wellness": true,
    "notes": true,
    "finance": true,
    "meals": true,
    "reading": true,
    "projects": true,
    "people": true,
    "home": true,
    "business": true
  }
}/*EDITMODE-END*/;

// Theme palettes — all share chroma/lightness, vary hue (oklch-derived hex)
const THEMES = {
  ochre:    { accent: '#B0763A', accentSoft: '#E8D7BE', name: 'Ochre' },
  olive:    { accent: '#6B7A3A', accentSoft: '#DBE0C4', name: 'Olive' },
  terracotta:{ accent: '#B45B47', accentSoft: '#ECC9BD', name: 'Terracotta' },
  ink:      { accent: '#3A4A6B', accentSoft: '#C4D0E0', name: 'Ink' },
  plum:     { accent: '#7A4A6B', accentSoft: '#E0C4D4', name: 'Plum' },
};

const TYPEFACES = {
  newsreader: { display: '"Newsreader", Georgia, serif', body: '"Inter", system-ui, sans-serif', mono: '"JT Mono", "IBM Plex Mono", monospace' },
  spectral:   { display: '"Spectral", Georgia, serif', body: '"Inter", system-ui, sans-serif', mono: '"JT Mono", monospace' },
  sans:       { display: '"Inter", system-ui, sans-serif', body: '"Inter", system-ui, sans-serif', mono: '"JT Mono", monospace' },
};

// Light/Dark palette (paper-planner feel)
const PALETTE = {
  light: {
    paper:    '#F5F1E8',
    paperAlt: '#EDE7D8',
    card:     '#FBF8F1',
    ink:      '#1C1A15',
    ink2:     '#3D3A32',
    ink3:     '#706A5C',
    ink4:     '#9A9484',
    rule:     '#D9D2C0',
    rule2:    '#E5DFCD',
    check:    '#1C1A15',
    complete: '#9A9484',
  },
  dark: {
    paper:    '#17161A',
    paperAlt: '#1E1C20',
    card:     '#212025',
    ink:      '#F0EDE4',
    ink2:     '#C9C5BA',
    ink3:     '#8A8578',
    ink4:     '#5A574F',
    rule:     '#2E2C30',
    rule2:    '#35333A',
    check:    '#F0EDE4',
    complete: '#5A574F',
  },
};

// ─────────────────────────────────────────────────────────────
// Mock data — realistic, no slop
// ─────────────────────────────────────────────────────────────

const todayISO = '2026-04-18'; // static for prototype

const INITIAL_TASKS = [
  { id: 't1', text: 'Send Q1 invoice to Aperture Co.', priority: 1, done: false, project: 'Business', time: '9:30' },
  { id: 't2', text: 'Review pull requests', priority: 2, done: true, project: 'Work' },
  { id: 't3', text: 'Call dentist to reschedule', priority: 1, done: false, project: 'Health' },
  { id: 't4', text: 'Water the monstera & fiddle leaf', priority: 3, done: false, project: 'Home' },
  { id: 't5', text: 'Draft proposal — Chen foundation', priority: 1, done: false, project: 'Business', time: '14:00' },
  { id: 't6', text: 'Reply to Marguerite\'s email', priority: 2, done: false, project: 'People' },
  { id: 't7', text: 'Pick up dry cleaning', priority: 3, done: false, project: 'Home' },
  { id: 't8', text: 'Read chapter 4 — "Slouching Towards Bethlehem"', priority: 3, done: false, project: 'Reading' },
];

const SCHEDULE = [
  { id: 's1', title: 'Morning pages', start: 7,    end: 7.5,  kind: 'ritual' },
  { id: 's2', title: 'Deep work — Chen proposal', start: 9,  end: 11,   kind: 'focus' },
  { id: 's3', title: 'Stand-up',    start: 11,    end: 11.5, kind: 'meeting' },
  { id: 's4', title: 'Lunch w/ Dev', start: 12.5, end: 13.5, kind: 'personal' },
  { id: 's5', title: 'Client call — Aperture', start: 14,  end: 15,   kind: 'meeting' },
  { id: 's6', title: 'Gym',         start: 17,    end: 18,   kind: 'wellness' },
  { id: 's7', title: 'Dinner & reading', start: 19, end: 21, kind: 'personal' },
];

const HABITS = [
  { id: 'h1', name: 'Morning pages', streak: 23, done: [1,1,1,1,1,0,1], icon: 'pen' },
  { id: 'h2', name: 'Move 30 min',   streak: 5,  done: [1,0,1,1,1,1,0], icon: 'run' },
  { id: 'h3', name: 'Read',          streak: 41, done: [1,1,1,1,1,1,1], icon: 'book' },
  { id: 'h4', name: 'No phone before 9', streak: 8, done: [1,1,0,1,1,1,0], icon: 'moon' },
  { id: 'h5', name: 'Meditate',      streak: 12, done: [1,1,1,0,1,1,1], icon: 'circle' },
];

const WELLNESS = {
  sleep: { hours: 7.4, quality: 82, bedtime: '23:14', wake: '06:38' },
  water: { cups: 4, goal: 8 },
  steps: { count: 3240, goal: 8000 },
  mood:  { score: 7, note: 'steady' },
};

const NOTES = [
  { id: 'n1', title: 'Proposal outline — Chen', snippet: 'Lead with the diagnostic, not the methodology. They care about outcomes, not our process…', date: 'Apr 16', tag: 'work' },
  { id: 'n2', title: 'Seeds for spring garden',  snippet: 'Tomato (San Marzano, Brandywine), basil, shishito, calendula for bees…', date: 'Apr 12', tag: 'home' },
  { id: 'n3', title: 'Things Dev said',          snippet: '"The antidote to anxiety is specificity." — worth sitting with.', date: 'Apr 9',  tag: 'journal' },
];

const FINANCE = {
  month: 'April',
  spent: 2847,
  budget: 4200,
  categories: [
    { name: 'Rent',      amount: 1650, of: 1650 },
    { name: 'Groceries', amount: 312,  of: 500 },
    { name: 'Dining',    amount: 189,  of: 250 },
    { name: 'Transit',   amount: 84,   of: 150 },
    { name: 'Business',  amount: 412,  of: 800 },
    { name: 'Other',     amount: 200,  of: 850 },
  ],
  income: 5800,
  saved: 1400,
};

const MEALS = [
  { day: 'Mon', breakfast: 'Oats + berries', lunch: 'Leftover soup', dinner: 'Sheet pan salmon' },
  { day: 'Tue', breakfast: 'Eggs on toast',  lunch: 'Grain bowl',    dinner: 'Pasta e fagioli' },
  { day: 'Wed', breakfast: 'Yogurt & nuts',  lunch: 'Out — café',    dinner: 'Roast chicken' },
  { day: 'Thu', breakfast: 'Smoothie',       lunch: 'Leftover chx',  dinner: 'Tacos' },
  { day: 'Fri', breakfast: 'Oats + berries', lunch: 'Grain bowl',    dinner: 'Pizza night' },
];

const READING = [
  { title: 'Slouching Towards Bethlehem', author: 'Joan Didion', progress: 62, status: 'reading' },
  { title: 'The Creative Act',            author: 'Rick Rubin',  progress: 100, status: 'done' },
  { title: 'A Pattern Language',          author: 'Christopher Alexander', progress: 14, status: 'reading' },
  { title: 'Four Thousand Weeks',         author: 'Oliver Burkeman', progress: 0,  status: 'queued' },
];

const PROJECTS = [
  { name: 'Chen proposal',    due: 'Apr 24', progress: 45, tasks: 7,  done: 3 },
  { name: 'Studio website',   due: 'May 12', progress: 20, tasks: 14, done: 3 },
  { name: 'Spring garden',    due: 'Ongoing', progress: 70, tasks: 5,  done: 4 },
  { name: 'Tax filing',       due: 'Apr 15', progress: 100, tasks: 4, done: 4 },
];

const PEOPLE = [
  { name: 'Marguerite',  last: '2 weeks ago', due: 'overdue',  relation: 'friend' },
  { name: 'Dad',         last: '4 days ago',  due: 'this week', relation: 'family' },
  { name: 'Dev',         last: 'yesterday',   due: 'ok',       relation: 'partner' },
  { name: 'Sam at Aperture', last: '1 week',  due: 'this week', relation: 'client' },
];

const HOME = [
  { chore: 'Laundry',       freq: 'Weekly',  last: '4 days ago', due: 'soon' },
  { chore: 'Water plants',  freq: 'Every 3d',last: 'Today',      due: 'ok' },
  { chore: 'Take out trash',freq: 'Weekly',  last: '6 days ago', due: 'overdue' },
  { chore: 'Clean bathroom',freq: 'Weekly',  last: '3 days ago', due: 'soon' },
];

const BUSINESS = {
  mrr: 8400,
  lastMonth: 7950,
  clients: 6,
  invoicesOutstanding: 2,
  nextInvoice: 'Aperture Co. — $4,200',
};

Object.assign(window, {
  TWEAK_DEFAULTS, THEMES, TYPEFACES, PALETTE, todayISO,
  INITIAL_TASKS, SCHEDULE, HABITS, WELLNESS, NOTES, FINANCE,
  MEALS, READING, PROJECTS, PEOPLE, HOME, BUSINESS,
});
